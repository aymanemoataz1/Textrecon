
namespace RestClient.Core.Models
{
    public class RequestHeader
    {
        public string Key { get;set; }

        public string Value { get; set; }   
    }
}